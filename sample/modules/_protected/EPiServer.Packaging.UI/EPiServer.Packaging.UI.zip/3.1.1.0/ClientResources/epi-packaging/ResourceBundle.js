//>>built
require(["epi/i18n","epi/i18n!epi/packaging/nls/EPiServer.Packaging.UI"]);