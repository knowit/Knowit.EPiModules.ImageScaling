//>>built
var profile={resourceTags:{test:function(_1,_2){return false;},copyOnly:function(_3,_4){return false;},amd:function(_5,_6){return /\.js$/.test(_5);}},trees:[[".",".",/(\/\.)|(~$)/]]};